# You Chrome Extension

**To test:**

1. Download or clone this repo into a separate folder
2. Go to **chrome://extensions** in the Chrome address bar 
3. At the top right, turn on **Developer mode**
4. Click **Load unpacked**
5. Find and select the extension in the folder you downloaded previously
